@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Create or Destroy — 真正透明桌面寵物安裝與啟動器

if not exist "CreateOrDestroy_桌寵_主程式.exe" (
    echo ⚡ 正在使用 Windows 內建 .NET Framework 為您本機編譯透明桌面寵物（免數位簽章攔截）...
    set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
    if not exist "%CSC%" set "CSC=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"
    "%CSC%" /nologo /target:winexe "/out:CreateOrDestroy_桌寵_主程式.exe" /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "/resource:_pet_assets.bin" "_NativePetApp.cs"
)

if exist "CreateOrDestroy_桌寵_主程式.exe" (
    start "" "CreateOrDestroy_桌寵_主程式.exe"
    exit /b 0
)

start "" "CreateOrDestroy_桌寵.exe"
