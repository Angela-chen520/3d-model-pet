@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if not exist "CreateOrDestroy_桌寵.exe" (
    if exist "%CSC%" (
        echo ⚡ 正在使用 Windows 內建 .NET 編譯器為您生成單一執行檔 CreateOrDestroy_桌寵.exe ...
        > "_pet_launcher.cs" (
            echo using System;
            echo using System.Diagnostics;
            echo using System.IO;
            echo class Program {
            echo     [STAThread]
            echo     static void Main() {
            echo         string dir = AppDomain.CurrentDomain.BaseDirectory;
            echo         string core = Path.Combine(dir, "CreateOrDestroy_桌寵單一執行包.html");
            echo         string url = new Uri(core).AbsoluteUri;
            echo         string[] edges = new string[] {
            echo             @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            echo             @"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            echo             @"C:\Program Files\Google\Chrome\Application\chrome.exe"
            echo         };
            echo         foreach (string e in edges) {
            echo             if (File.Exists(e)) {
            echo                 Process.Start(e, "--app=\"" + url + "\" --window-size=540,840");
            echo                 return;
            echo             }
            echo         }
            echo         Process.Start(core);
            echo     }
            echo }
        )
        "%CSC%" /nologo /target:winexe /out:"CreateOrDestroy_桌寵.exe" "_pet_launcher.cs" >nul 2>&1
        del /q "_pet_launcher.cs" >nul 2>&1
    )
)

if exist "CreateOrDestroy_桌寵.exe" (
    start "" "CreateOrDestroy_桌寵.exe"
) else (
    start msedge "--app=%~dp0CreateOrDestroy_桌寵單一執行包.html" --window-size=540,840 2>nul || start "" "%~dp0CreateOrDestroy_桌寵單一執行包.html"
)
